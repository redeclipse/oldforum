
painting textures for the map sm64, similar to some famous plumber's first 3d jump and run action.
original design by Nintendo (1996), texture remakes cc-by-sa-4.0
