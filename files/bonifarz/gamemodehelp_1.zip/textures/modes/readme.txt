
The placeholder icons here are just (unmodified) copies of existing game mode icons. Source:
http://svn.icculus.org/redeclipse/data/textures/
