To install these, simply drop the "textures" folder inside your "My Games/red eclipse/" folder. 

Textures made by SniperGoth, using Blender and PDN.