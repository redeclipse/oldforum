This work, by Molexted, is a derivative of tree12, which is a work of the Red Eclipse Team (redeclipse.net).
Therefore, it is bound by the same CC-BY-SA 3.0 license found with the original work. This license is found with the original work.
