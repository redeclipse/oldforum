USAGE:

	Use "package.cfg" from "noglare" folder to add texture to your maps without "glare" effects.

