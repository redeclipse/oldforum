"TESSERACT" USAGE:

	1. Install "ses" folder from "data" folder to your "tesseract/media/texture" folder.
	2. Remove "package.cfg" from "ses/tiles" folder.
	3. Install "media" folder from "tesseract" folder to your "tesseract" folder.
	4. Use "package.cfg" or "texload.cfg" from "tesseract" folder to add texture to your maps.

