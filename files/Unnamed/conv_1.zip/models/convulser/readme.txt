This work, made by Unnamed (Viktor.Hahn@web.de), is
licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
http://creativecommons.org/licenses/by-sa/3.0/