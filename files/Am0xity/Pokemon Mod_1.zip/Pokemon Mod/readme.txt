﻿//Pokemon Mod readme//do not modify this readme//
Pokemon by Am0xity

This is just a map version to see what people would think of the map.

Meant for feedback.

[So far I have made Littleroot town, Route 101, Some of Odale Town, many, many scripts including PokeMart and PokeCenter, along with custom physics, weapon variables, and more!] 

I am planning to create the entire Hoenn region in one piece

updates ---
{none yet}

